// ====== УПРАВЛЕНИЕ СПИСКОМ ДЕЛ ======

// Загрузка задач из localStorage или создание начальных
let tasks = [];

// DOM элементы
const taskInput = document.getElementById('taskInput');
const createBtn = document.getElementById('createBtn');
const clearAllBtn = document.getElementById('clearAllBtn');
const tasksContainer = document.getElementById('tasksContainer');

// Ключ для localStorage
const STORAGE_KEY = 'todo_list_tasks';

// Форматирование даты: ДД.ММ.ГГ
function getFormattedDate() {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = String(now.getFullYear()).slice(-2);
    return `${day}.${month}.${year}`;
}

// Загрузка задач из localStorage
function loadTasks() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
        try {
            tasks = JSON.parse(saved);
        } catch(e) {
            console.error('Ошибка загрузки задач:', e);
            tasks = [];
        }
    } else {
        // Начальные задачи
        tasks = [
            { id: Date.now() + 1, text: 'почесать кошку очень-очень длинный текст для проверки', completed: true, date: '02.02.26' },
            { id: Date.now() + 2, text: 'собрать картошку', completed: false, date: '02.02.26' },
            { id: Date.now() + 3, text: 'положить в лукошко', completed: false, date: '02.02.26' },
            { id: Date.now() + 4, text: 'приготовить окрошку', completed: false, date: '02.02.26' }
        ];
    }
}

// Сохранение задач в localStorage
function saveTasks() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

// Переключение статуса задачи
function toggleTask(id) {
    const task = tasks.find(t => t.id === id);
    if (task) {
        task.completed = !task.completed;
        saveTasks();
        renderTasks();
    }
}

// Удаление задачи
function deleteTask(id) {
    tasks = tasks.filter(task => task.id !== id);
    saveTasks();
    renderTasks();
}

// Добавление новой задачи
function addTask() {
    const text = taskInput.value.trim();
    
    if (!text) {
        alert('Пожалуйста, введите текст задачи');
        return;
    }
    
    const newTask = {
        id: Date.now(),
        text: text,
        completed: false,
        date: getFormattedDate()
    };
    
    tasks.unshift(newTask); // Добавляем в начало списка
    saveTasks();
    renderTasks();
    taskInput.value = '';
    taskInput.focus();
}

// Очистка всех задач
function clearAllTasks() {
    if (tasks.length > 0 && confirm('Вы уверены, что хотите удалить все задачи?')) {
        tasks = [];
        saveTasks();
        renderTasks();
    }
}

// Отображение задач
function renderTasks() {
    if (!tasksContainer) return;
    
    if (tasks.length === 0) {
        tasksContainer.innerHTML = '<div class="empty">✨ Нет задач. Добавьте новую! ✨</div>';
        return;
    }
    
    const fragment = document.createDocumentFragment();
    
    tasks.forEach(task => {
        // Создаём элемент задачи
        const itemDiv = document.createElement('div');
        itemDiv.className = `item ${task.completed ? 'item--done' : ''}`;
        
        // Скрытый чекбокс
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.className = 'item__checkbox';
        checkbox.checked = task.completed;
        checkbox.id = `task_${task.id}`;
        
        // Область контента (кликабельная для чекбокса)
        const contentDiv = document.createElement('div');
        contentDiv.className = 'item__content';
        contentDiv.onclick = (e) => {
            e.stopPropagation();
            toggleTask(task.id);
        };
        
        // Текст задачи
        const labelDiv = document.createElement('div');
        labelDiv.className = `item__label ${task.completed ? 'item__label--done' : ''}`;
        labelDiv.textContent = task.text;
        
        // Дата
        const dateDiv = document.createElement('div');
        dateDiv.className = 'item__date';
        dateDiv.textContent = `от ${task.date}`;
        
        contentDiv.appendChild(labelDiv);
        contentDiv.appendChild(dateDiv);
        
        // Крестик удаления
        const deleteSpan = document.createElement('span');
        deleteSpan.className = 'item__icon item__icon--x';
        deleteSpan.textContent = '✖';
        deleteSpan.onclick = (e) => {
            e.stopPropagation();
            deleteTask(task.id);
        };
        
        // Собираем элемент
        itemDiv.appendChild(checkbox);
        itemDiv.appendChild(contentDiv);
        itemDiv.appendChild(deleteSpan);
        
        fragment.appendChild(itemDiv);
    });
    
    tasksContainer.innerHTML = '';
    tasksContainer.appendChild(fragment);
}

// Инициализация приложения
function init() {
    // Проверяем наличие необходимых элементов
    if (!tasksContainer) {
        console.error('Контейнер для задач не найден');
        return;
    }
    
    loadTasks();
    renderTasks();
    
    // Назначаем обработчики событий
    if (createBtn) {
        createBtn.addEventListener('click', addTask);
    }
    
    if (clearAllBtn) {
        clearAllBtn.addEventListener('click', clearAllTasks);
    }
    
    if (taskInput) {
        taskInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                addTask();
            }
        });
    }
}

// Запуск приложения после полной загрузки DOM
document.addEventListener('DOMContentLoaded', init);