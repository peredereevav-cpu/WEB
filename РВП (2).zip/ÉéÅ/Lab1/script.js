
let tasks = [];


const taskInput = document.getElementById('taskInput');
const createBtn = document.getElementById('createBtn');
const clearAllBtn = document.getElementById('clearAllBtn');
const tasksContainer = document.getElementById('tasksContainer');


const STORAGE_KEY = 'todo_list_tasks';


function getFormattedDate() {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = String(now.getFullYear()).slice(-2);
    return `${day}.${month}.${year}`;
}


function loadTasks() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
        try {
            tasks = JSON.parse(saved);
        } catch(e) {
            console.error('Ошибка загрузки задач:', e);
            tasks = [];
        }
    } else {
        tasks = [
            { id: Date.now() + 1, text: 'почесать кошку очень-очень длинный текст для проверки', completed: true, date: '02.02.26' },
            { id: Date.now() + 2, text: 'собрать картошку', completed: false, date: '02.02.26' },
            { id: Date.now() + 3, text: 'положить в лукошко', completed: false, date: '02.02.26' },
            { id: Date.now() + 4, text: 'приготовить окрошку', completed: false, date: '02.02.26' }
        ];
    }
}

function saveTasks() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

function toggleTask(id) {
    const task = tasks.find(t => t.id === id);
    if (task) {
        task.completed = !task.completed;
        saveTasks();
        renderTasks();
    }
}

function deleteTask(id) {
    tasks = tasks.filter(task => task.id !== id);
    saveTasks();
    renderTasks();
}

function addTask() {
    const text = taskInput.value.trim();
    
    if (!text) {
        alert('Пожалуйста, введите текст задачи');
        return;
    }
    
    const newTask = {
        id: Date.now(),
        text: text,
        completed: false,
        date: getFormattedDate()
    };
    
    tasks.unshift(newTask);
    saveTasks();
    renderTasks();
    taskInput.value = '';
    taskInput.focus();
}

function clearAllTasks() {
    if (tasks.length > 0 && confirm('Вы уверены, что хотите удалить все задачи?')) {
        tasks = [];
        saveTasks();
        renderTasks();
    }
}

function renderTasks() {
    if (!tasksContainer) return;
    
    if (tasks.length === 0) {
        tasksContainer.innerHTML = '<div class="empty">✨ Нет задач. Добавьте новую! ✨</div>';
        return;
    }
    
    const fragment = document.createDocumentFragment();
    
    tasks.forEach(task => {
        const itemDiv = document.createElement('div');
        itemDiv.className = `item ${task.completed ? 'item--done' : ''}`;
        
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.className = 'item__checkbox';
        checkbox.checked = task.completed;
        checkbox.id = `task_${task.id}`;
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'item__content';
        contentDiv.onclick = (e) => {
            e.stopPropagation();
            toggleTask(task.id);
        };
        
        const labelDiv = document.createElement('div');
        labelDiv.className = `item__label ${task.completed ? 'item__label--done' : ''}`;
        labelDiv.textContent = task.text;
        
        const dateDiv = document.createElement('div');
        dateDiv.className = 'item__date';
        dateDiv.textContent = `от ${task.date}`;
        
        contentDiv.appendChild(labelDiv);
        contentDiv.appendChild(dateDiv);
        
        const deleteSpan = document.createElement('span');
        deleteSpan.className = 'item__icon item__icon--x';
        deleteSpan.textContent = '✖';
        deleteSpan.onclick = (e) => {
            e.stopPropagation();
            deleteTask(task.id);
        };
        
        itemDiv.appendChild(checkbox);
        itemDiv.appendChild(contentDiv);
        itemDiv.appendChild(deleteSpan);
        
        fragment.appendChild(itemDiv);
    });
    
    tasksContainer.innerHTML = '';
    tasksContainer.appendChild(fragment);
}

function init() {
    if (!tasksContainer) {
        console.error('Контейнер для задач не найден');
        return;
    }
    
    loadTasks();
    renderTasks();
    
    if (createBtn) {
        createBtn.addEventListener('click', addTask);
    }
    
    if (clearAllBtn) {
        clearAllBtn.addEventListener('click', clearAllTasks);
    }
    
    if (taskInput) {
        taskInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                addTask();
            }
        });
    }
}

document.addEventListener('DOMContentLoaded', init);